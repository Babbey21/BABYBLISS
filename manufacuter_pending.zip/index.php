<?php
session_start();
require_once "config.php";

// Get filter parameters
$category_filter = isset($_GET['category']) ? intval($_GET['category']) : 0;
$price_min = isset($_GET['price_min']) ? floatval($_GET['price_min']) : 0;
$price_max = isset($_GET['price_max']) ? floatval($_GET['price_max']) : 999999;
$condition_filter = isset($_GET['condition']) ? mysqli_real_escape_string($conn, $_GET['condition']) : '';
$manufacturer_filter = isset($_GET['manufacturer']) ? intval($_GET['manufacturer']) : 0;
$sort = isset($_GET['sort']) ? mysqli_real_escape_string($conn, $_GET['sort']) : 'featured';
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Build query
$where = "p.status = 'active' AND p.is_active = 1";
if ($category_filter) $where .= " AND p.category_id = $category_filter";
if ($price_min > 0) $where .= " AND p.price >= $price_min";
if ($price_max < 999999) $where .= " AND p.price <= $price_max";
if ($condition_filter) $where .= " AND p.condition_type = '$condition_filter'";
if ($manufacturer_filter) $where .= " AND p.manufacturer_id = $manufacturer_filter";
if ($search) $where .= " AND (p.name LIKE '%$search%' OR p.description LIKE '%$search%' OR m.company_name LIKE '%$search%')";

$order_by = "p.created_at DESC";
if ($sort == 'price_low') $order_by = "p.price ASC";
if ($sort == 'price_high') $order_by = "p.price DESC";
if ($sort == 'newest') $order_by = "p.created_at DESC";
if ($sort == 'popular') $order_by = "p.orders_count DESC";
if ($sort == 'rating') $order_by = "p.rating DESC";

$products_query = "SELECT p.*, m.company_name, m.country as manufacturer_country, m.logo as manufacturer_logo, m.rating as manufacturer_rating, m.total_sales,
                          c.name as category_name, c.icon as category_icon
                   FROM products p 
                   LEFT JOIN manufacturers m ON p.manufacturer_id = m.id 
                   LEFT JOIN categories c ON p.category_id = c.id
                   WHERE $where
                   ORDER BY $order_by";
$products = mysqli_query($conn, $products_query);
$total_products = mysqli_num_rows($products);

// Fetch categories
$categories = mysqli_query($conn, "SELECT * FROM categories WHERE is_active = 1 ORDER BY name ASC");

// Fetch manufacturers for filter
$manufacturers = mysqli_query($conn, "SELECT id, company_name, country, logo, total_sales FROM manufacturers WHERE verification_status = 'verified' AND is_active = 1 ORDER BY company_name ASC");

// Cart count
$cart_count = isset($_SESSION['cart']) ? array_sum(array_column($_SESSION['cart'], 'quantity')) : 0;

// Check user role
$is_admin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
$is_manufacturer = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'manufacturer';

function isImagePath($str) {
    if (empty($str)) return false;
    $exts = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
    foreach ($exts as $ext) if (stripos($str, $ext) !== false) return true;
    return strpos($str, '/') !== false || strpos($str, 'uploads') !== false;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>BabyBliss Marketplace – Shop from Verified Manufacturers</title>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
  <style>
    :root { --cream: #FFF8F0; --blush: #F2A7B3; --rose: #E8738A; --deep-rose: #C44D65; --mint: #A8D8C8; --mint-dark: #5FB8A0; --sky: #B8D8E8; --gold: #F5C842; --warm-brown: #7C5C4A; --soft-brown: #C4997A; --white: #FFFFFF; --text-dark: #2D1B14; --text-mid: #6B4C3B; --text-light: #A07D6A; --shadow: rgba(196,77,101,0.12); --radius: 20px; }
    * { margin:0; padding:0; box-sizing:border-box; }
    html { scroll-behavior: smooth; }
    body { font-family: 'DM Sans', sans-serif; background: var(--cream); color: var(--text-dark); overflow-x: hidden; }

    header { background: var(--white); position: sticky; top: 0; z-index: 999; box-shadow: 0 2px 20px var(--shadow); }
    .header-top { background: var(--deep-rose); text-align: center; padding: 6px; font-size: 13px; color: var(--white); letter-spacing: 0.5px; }
    .header-main { display: flex; align-items: center; justify-content: space-between; padding: 0 48px; height: 72px; }
    .logo { display: flex; align-items: center; gap: 10px; text-decoration: none; }
    .logo-icon { width: 44px; height: 44px; background: linear-gradient(135deg, var(--blush), var(--deep-rose)); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .logo-text { font-family: 'Playfair Display', serif; font-size: 26px; font-weight: 700; color: var(--deep-rose); line-height: 1; }
    .logo-sub { font-size: 10px; font-weight: 300; color: var(--text-light); letter-spacing: 2px; text-transform: uppercase; }
    .search-bar { flex: 1; max-width: 500px; margin: 0 24px; position: relative; }
    .search-bar input { width: 100%; padding: 12px 20px 12px 44px; border: 2px solid #F0E4DC; border-radius: 12px; font-family: 'DM Sans', sans-serif; font-size: 14px; outline: none; transition: all 0.2s; }
    .search-bar input:focus { border-color: var(--rose); box-shadow: 0 0 0 4px rgba(232,115,138,0.1); }
    .search-bar i { position: absolute; left: 16px; top: 50%; transform: translateY(-50%); color: var(--text-light); }
    .search-bar button { position: absolute; right: 6px; top: 50%; transform: translateY(-50%); background: var(--rose); color: white; border: none; padding: 8px 16px; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; }
    nav { display: flex; gap: 28px; align-items: center; }
    nav a { font-size: 15px; font-weight: 500; color: var(--text-mid); text-decoration: none; position: relative; padding: 4px 0; transition: color 0.2s; }
    nav a::after { content: ''; position: absolute; bottom: -2px; left: 0; width: 0; height: 2px; background: var(--rose); border-radius: 2px; transition: width 0.3s; }
    nav a:hover { color: var(--deep-rose); }
    nav a:hover::after { width: 100%; }
    .header-actions { display: flex; align-items: center; gap: 12px; }
    .icon-btn { position: relative; background: none; border: none; font-size: 20px; color: var(--text-mid); cursor: pointer; padding: 8px; border-radius: 10px; transition: all 0.2s; text-decoration: none; }
    .icon-btn:hover { background: var(--cream); color: var(--deep-rose); }
    .badge { position: absolute; top: 2px; right: 2px; background: var(--deep-rose); color: var(--white); font-size: 10px; font-weight: 600; width: 18px; height: 18px; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
    .btn-login { padding: 9px 22px; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; border: 2px solid var(--rose); color: var(--rose); background: transparent; transition: all 0.2s; text-decoration: none; }
    .btn-login:hover { background: var(--rose); color: var(--white); }
    .btn-register { padding: 9px 22px; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; border: none; background: linear-gradient(135deg, var(--rose), var(--deep-rose)); color: var(--white); transition: all 0.2s; text-decoration: none; }
    .btn-register:hover { transform: translateY(-1px); box-shadow: 0 6px 18px rgba(196,77,101,0.35); }
    .btn-sell { padding: 9px 22px; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; border: none; background: linear-gradient(135deg, var(--mint-dark), #3A9E88); color: var(--white); transition: all 0.2s; text-decoration: none; }
    .btn-sell:hover { transform: translateY(-1px); box-shadow: 0 6px 18px rgba(95,184,160,0.35); }

    .marketplace-hero { background: linear-gradient(135deg, #1a0a0e 0%, #3a1a24 50%, #5a2a34 100%); padding: 60px 48px; display: flex; align-items: center; justify-content: space-between; position: relative; overflow: hidden; }
    .marketplace-hero::before { content: ''; position: absolute; inset: 0; background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Ccircle cx='30' cy='30' r='4'/%3E%3C/g%3E%3C/svg%3E"); }
    .hero-content { position: relative; z-index: 1; max-width: 600px; }
    .hero-content h1 { font-family: 'Playfair Display', serif; font-size: 42px; color: var(--white); margin-bottom: 16px; line-height: 1.2; }
    .hero-content p { color: rgba(255,255,255,0.8); font-size: 17px; margin-bottom: 28px; line-height: 1.6; }
    .hero-stats { display: flex; gap: 32px; margin-top: 24px; }
    .hero-stat { text-align: center; }
    .hero-stat-value { font-size: 28px; font-weight: 700; color: var(--blush); }
    .hero-stat-label { font-size: 13px; color: rgba(255,255,255,0.6); margin-top: 4px; }
    .hero-emoji { font-size: 120px; opacity: 0.15; position: absolute; right: 80px; top: 50%; transform: translateY(-50%); }

    .main-container { max-width: 1400px; margin: 0 auto; padding: 40px 48px; display: grid; grid-template-columns: 260px 1fr; gap: 32px; }

    .sidebar-filters { background: var(--white); border-radius: var(--radius); padding: 24px; box-shadow: 0 4px 20px var(--shadow); height: fit-content; position: sticky; top: 100px; }
    .filter-section { margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid #F0E4DC; }
    .filter-section:last-child { border-bottom: none; margin-bottom: 0; }
    .filter-title { font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: var(--text-dark); margin-bottom: 14px; display: flex; align-items: center; gap: 8px; }
    .filter-title i { color: var(--rose); }
    .filter-list { display: flex; flex-direction: column; gap: 8px; }
    .filter-item { display: flex; align-items: center; gap: 10px; padding: 8px 10px; border-radius: 8px; cursor: pointer; transition: all 0.2s; font-size: 14px; color: var(--text-mid); text-decoration: none; }
    .filter-item:hover { background: var(--cream); color: var(--deep-rose); }
    .filter-item.active { background: linear-gradient(135deg, #FFF0F3, #FFE4EA); color: var(--deep-rose); font-weight: 600; }
    .filter-item input[type="checkbox"] { accent-color: var(--rose); }
    .filter-item .count { margin-left: auto; font-size: 12px; color: var(--text-light); background: var(--cream); padding: 2px 8px; border-radius: 10px; }
    .price-range { display: flex; gap: 8px; margin-top: 8px; }
    .price-range input { width: 100%; padding: 8px 12px; border: 2px solid #F0E4DC; border-radius: 8px; font-size: 13px; }
    .price-range button { padding: 8px 16px; background: var(--rose); color: white; border: none; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; }

    .products-area { }
    .results-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    .results-count { font-size: 14px; color: var(--text-light); }
    .results-count strong { color: var(--text-dark); }
    .sort-bar { display: flex; align-items: center; gap: 12px; }
    .sort-bar label { font-size: 13px; color: var(--text-light); }
    .sort-bar select { padding: 8px 16px; border: 2px solid #F0E4DC; border-radius: 10px; font-family: 'DM Sans', sans-serif; font-size: 14px; color: var(--text-mid); background: var(--white); cursor: pointer; outline: none; }

    .products-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
    .product-card { background: var(--white); border-radius: 16px; overflow: hidden; transition: all 0.3s; position: relative; cursor: pointer; border: 1px solid transparent; }
    .product-card:hover { transform: translateY(-4px); box-shadow: 0 16px 40px rgba(196,77,101,0.15); border-color: var(--blush); }
    .product-badge { position: absolute; top: 12px; left: 12px; background: var(--deep-rose); color: var(--white); font-size: 10px; font-weight: 700; padding: 4px 10px; border-radius: 6px; z-index: 2; text-transform: uppercase; }
    .product-badge.new { background: var(--mint-dark); }
    .product-badge.sale { background: var(--gold); color: var(--text-dark); }
    .product-img { width: 100%; height: 200px; background: linear-gradient(135deg, #FFF0F5, #FFE4EA); display: flex; align-items: center; justify-content: center; font-size: 80px; position: relative; overflow: hidden; }
    .product-img img { width: 100%; height: 100%; object-fit: cover; }
    .product-body { padding: 16px; }
    .manufacturer-row { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
    .manufacturer-row img { width: 20px; height: 20px; border-radius: 4px; object-fit: cover; }
    .manufacturer-row span { font-size: 12px; color: var(--text-light); }
    .manufacturer-row .verified { color: var(--mint-dark); font-size: 11px; }
    .product-name { font-size: 15px; font-weight: 600; color: var(--text-dark); margin-bottom: 6px; line-height: 1.4; height: 42px; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
    .product-rating { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; }
    .stars { color: var(--gold); font-size: 12px; }
    .review-count { font-size: 11px; color: var(--text-light); }
    .product-price { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; }
    .price-current { font-size: 20px; font-weight: 700; color: var(--deep-rose); }
    .price-old { font-size: 13px; color: var(--text-light); text-decoration: line-through; }
    .product-meta { display: flex; align-items: center; justify-content: space-between; font-size: 11px; color: var(--text-light); margin-bottom: 10px; }
    .product-meta span { display: flex; align-items: center; gap: 4px; }
    .btn-cart { width: 100%; padding: 10px; background: linear-gradient(135deg, var(--rose), var(--deep-rose)); color: var(--white); border: none; border-radius: 10px; font-size: 13px; font-weight: 600; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; transition: all 0.25s; text-decoration: none; }
    .btn-cart:hover { transform: translateY(-1px); box-shadow: 0 6px 16px rgba(196,77,101,0.3); }
    .condition-tag { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 600; text-transform: uppercase; }
    .condition-new { background: #EAF8F4; color: #2E7D62; }
    .condition-used { background: #FFF8E0; color: #B8860B; }
    .condition-refurbished { background: #E0E0FF; color: #5A5ACD; }

    .manufacturer-sidebar { margin-top: 24px; }
    .manufacturer-item { display: flex; align-items: center; gap: 10px; padding: 10px; border-radius: 10px; cursor: pointer; transition: all 0.2s; text-decoration: none; color: var(--text-mid); }
    .manufacturer-item:hover { background: var(--cream); }
    .manufacturer-item img { width: 32px; height: 32px; border-radius: 8px; object-fit: cover; background: linear-gradient(135deg, #E8E0FF, #D0C4FF); }
    .manufacturer-info { flex: 1; }
    .manufacturer-info .name { font-size: 13px; font-weight: 600; }
    .manufacturer-info .location { font-size: 11px; color: var(--text-light); }

    .no-products { text-align: center; padding: 80px 20px; grid-column: 1 / -1; }
    .no-products-icon { font-size: 80px; margin-bottom: 20px; opacity: 0.5; }
    .no-products h3 { font-family: 'Playfair Display', serif; font-size: 24px; margin-bottom: 10px; }
    .no-products p { color: var(--text-light); }

    footer { background: #1E0F0A; color: rgba(255,255,255,0.8); margin-top: 60px; }
    .footer-main { display: grid; grid-template-columns: 2fr 1fr 1fr 1.2fr; gap: 48px; padding: 56px 48px; }
    .footer-logo { font-family: 'Playfair Display', serif; font-size: 28px; color: var(--white); margin-bottom: 14px; }
    .footer-about { font-size: 14px; line-height: 1.7; margin-bottom: 20px; }
    .footer-col h4 { font-size: 14px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; color: var(--white); margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid rgba(255,255,255,0.12); }
    .footer-col ul { list-style: none; display: flex; flex-direction: column; gap: 10px; }
    .footer-col ul li a { font-size: 14px; color: rgba(255,255,255,0.65); text-decoration: none; transition: color 0.2s; }
    .footer-col ul li a:hover { color: var(--blush); }
    .footer-bottom { border-top: 1px solid rgba(255,255,255,0.08); padding: 20px 48px; display: flex; align-items: center; justify-content: space-between; }
    .footer-bottom p { font-size: 13px; color: rgba(255,255,255,0.4); }


    .carousel-wrap { position: relative; overflow: hidden; margin-bottom: 0; }
    .carousel { display: flex; transition: transform 0.6s cubic-bezier(.4,0,.2,1); }
    .slide { min-width: 100%; height: 520px; display: flex; align-items: center; position: relative; overflow: hidden; }
    .slide-1 { background: linear-gradient(135deg, #FDE8F0 0%, #FFDCEA 50%, #FFB8CE 100%); }
    .slide-2 { background: linear-gradient(135deg, #E8F8F5 0%, #C8EDE6 50%, #A8D8C8 100%); }
    .slide-3 { background: linear-gradient(135deg, #FFF3D4 0%, #FFE8A8 50%, #FFD870 100%); }
    .slide-4 { background: linear-gradient(135deg, #E8F0FF 0%, #C8D8FF 50%, #A8B8FF 100%); }
    .slide-content { position: relative; z-index: 2; padding: 0 80px; max-width: 580px; animation: fadeInLeft 0.7s ease both; }
    @keyframes fadeInLeft { from { opacity: 0; transform: translateX(-40px); } to { opacity: 1; transform: translateX(0); } }
    .slide-tag { display: inline-block; background: var(--deep-rose); color: var(--white); font-size: 11px; font-weight: 600; letter-spacing: 2px; text-transform: uppercase; padding: 5px 14px; border-radius: 20px; margin-bottom: 16px; }
    .slide h1 { font-family: 'Playfair Display', serif; font-size: 52px; line-height: 1.1; color: var(--text-dark); margin-bottom: 14px; }
    .slide p { font-size: 17px; color: var(--text-mid); margin-bottom: 28px; line-height: 1.6; }
    .slide-cta { display: inline-flex; align-items: center; gap: 10px; padding: 14px 30px; border-radius: 14px; background: linear-gradient(135deg, var(--rose), var(--deep-rose)); color: var(--white); font-size: 15px; font-weight: 600; text-decoration: none; transition: all 0.25s; }
    .slide-cta:hover { transform: translateY(-2px); box-shadow: 0 10px 28px rgba(196,77,101,0.4); }
    .slide-img { position: absolute; right: 80px; bottom: 0; font-size: 220px; line-height: 1; opacity: 0.18; filter: drop-shadow(0 20px 40px rgba(0,0,0,0.1)); }
    .slide-img-main { position: absolute; right: 60px; bottom: 0; font-size: 160px; animation: float 3s ease-in-out infinite; }
    @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-16px)} }
    .carousel-btn { position: absolute; top: 50%; transform: translateY(-50%); z-index: 10; background: var(--white); border: none; width: 48px; height: 48px; border-radius: 50%; cursor: pointer; font-size: 18px; color: var(--deep-rose); box-shadow: 0 4px 16px var(--shadow); display: flex; align-items: center; justify-content: center; transition: all 0.2s; }
    .carousel-btn:hover { background: var(--deep-rose); color: var(--white); }
    .carousel-btn.prev { left: 24px; }
    .carousel-btn.next { right: 24px; }
    .carousel-dots { position: absolute; bottom: 18px; left: 50%; transform: translateX(-50%); display: flex; gap: 8px; }
    .dot { width: 8px; height: 8px; border-radius: 4px; background: rgba(196,77,101,0.3); cursor: pointer; transition: all 0.3s; }
    .dot.active { width: 24px; background: var(--deep-rose); }
    @media (max-width: 1100px) { .products-grid { grid-template-columns: repeat(2, 1fr); } .main-container { grid-template-columns: 1fr; } .sidebar-filters { position: static; } }
    @media (max-width: 768px) { .products-grid { grid-template-columns: 1fr; } .header-main { padding: 0 20px; flex-wrap: wrap; height: auto; padding: 12px 20px; } .search-bar { order: 3; width: 100%; margin: 10px 0 0; max-width: none; } nav { display: none; } .marketplace-hero { padding: 40px 20px; } .hero-emoji { display: none; } .main-container { padding: 20px; } }
  </style>
</head>
<body>

<header>
  <div class="header-top">🌸 Free shipping on orders over Tsh 50,000 · Buyer Protection with Escrow · Verified Sellers Only 🍼</div>
  <div class="header-main">
    <a href="index.php" class="logo">
      <div class="logo-icon">🍼</div>
      <div><div class="logo-text">BabyBliss</div><div class="logo-sub">Marketplace</div></div>
    </a>
    <form class="search-bar" action="index.php" method="GET">
      <i class="fas fa-search"></i>
      <input type="text" name="search" placeholder="Search products, manufacturers, categories..." value="<?= htmlspecialchars($search) ?>"/>
      <button type="submit">Search</button>
    </form>
    <nav>
      <a href="index.php">Home</a>
      <a href="index.php?sort=popular">Popular</a>
      <a href="index.php?sort=newest">New Arrivals</a>
      <a href="index.php?condition=used">Deals</a>
    </nav>
    <div class="header-actions">
      <a href="cart.php" class="icon-btn">
        <i class="fas fa-shopping-cart"></i>
        <?php if ($cart_count > 0): ?><span class="badge"><?= $cart_count ?></span><?php endif; ?>
      </a>
      <a href="wishlist.php" class="icon-btn"><i class="fas fa-heart"></i></a>
      <?php if(isset($_SESSION['user_name'])): ?>
        <?php if($is_manufacturer): ?>
          <a href="manufacturer_dashboard.php" class="btn-sell"><i class="fas fa-store"></i> My Store</a>
        <?php elseif($is_admin): ?>
          <a href="admin.php" class="btn-login" style="background: linear-gradient(135deg, #8B7FD4, #6B5DB4); color: white; border: none;"><i class="fas fa-crown"></i> Admin</a>
        <?php else: ?>
          <a href="orders.php" class="icon-btn" title="My Orders"><i class="fas fa-clipboard-list"></i></a>
        <?php endif; ?>
        <a href="logout.php" class="btn-login">Logout</a>
      <?php else: ?>
        <a href="login.php" class="btn-login">Sign In</a>
        <a href="register.php?role=manufacturer" class="btn-sell"><i class="fas fa-store"></i> Sell on BabyBliss</a>
      <?php endif; ?>
    </div>
  </div>
</header>

<div class="carousel-wrap">
  <div class="carousel" id="carousel">
    <div class="slide slide-1">
      <div class="slide-content">
        <div class="slide-tag">✨ New Arrivals</div>
        <h1>Magical Toys for Little Explorers</h1>
        <p>Discover beautifully crafted toys that spark imagination and nurture development at every stage.</p>
        <a href="#products" class="slide-cta"><i class="fas fa-shopping-bag"></i> Shop Now</a>
      </div>
      <div class="slide-img">🧸</div>
      <div class="slide-img-main">🧸</div>
    </div>
    <div class="slide slide-2">
      <div class="slide-content">
        <div class="slide-tag" style="background:var(--mint-dark)">🌿 Eco-Friendly</div>
        <h1>Safe & Natural Baby Essentials</h1>
        <p>Organic, non-toxic, and lovingly designed products for your precious little ones.</p>
        <a href="#products" class="slide-cta" style="background:linear-gradient(135deg,var(--mint-dark),#3A9E88)"><i class="fas fa-leaf"></i> Explore</a>
      </div>
      <div class="slide-img">🌿</div>
      <div class="slide-img-main">🎀</div>
    </div>
    <div class="slide slide-3">
      <div class="slide-content">
        <div class="slide-tag" style="background:var(--gold);color:var(--text-dark)">⚡ Hot Deals</div>
        <h1>Summer Sale – Up to 40% Off!</h1>
        <p>Grab amazing deals on our most popular baby products before they're gone.</p>
        <a href="#products" class="slide-cta" style="background:linear-gradient(135deg,#E8A800,#C88A00)"><i class="fas fa-tag"></i> View Deals</a>
      </div>
      <div class="slide-img">⭐</div>
      <div class="slide-img-main">🎉</div>
    </div>
    <div class="slide slide-4">
      <div class="slide-content">
        <div class="slide-tag" style="background:#6678CC">🎓 Learning</div>
        <h1>Smart Toys That Grow with Your Child</h1>
        <p>Educational toys designed by child development experts to make learning joyful.</p>
        <a href="#products" class="slide-cta" style="background:linear-gradient(135deg,#6678CC,#4455AA)"><i class="fas fa-star"></i> Discover</a>
      </div>
      <div class="slide-img">📚</div>
      <div class="slide-img-main">🚀</div>
    </div>
  </div>
  <button class="carousel-btn prev" onclick="moveSlide(-1)"><i class="fas fa-chevron-left"></i></button>
  <button class="carousel-btn next" onclick="moveSlide(1)"><i class="fas fa-chevron-right"></i></button>
  <div class="carousel-dots" id="dots">
    <div class="dot active" onclick="goSlide(0)"></div>
    <div class="dot" onclick="goSlide(1)"></div>
    <div class="dot" onclick="goSlide(2)"></div>
    <div class="dot" onclick="goSlide(3)"></div>
  </div>
</div>

<div class="marketplace-hero">
  <div class="hero-content">
    <div style="display: inline-block; background: var(--rose); color: white; padding: 4px 14px; border-radius: 20px; font-size: 11px; font-weight: 600; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 16px;">🌍 Global Marketplace</div>
    <h1>Shop Direct from Manufacturers Worldwide</h1>
    <p>Discover thousands of baby products from verified manufacturers. Filter by price, condition, location, and more. Secure payments with buyer protection.</p>
    <div class="hero-stats">
      <div class="hero-stat"><div class="hero-stat-value">500+</div><div class="hero-stat-label">Manufacturers</div></div>
      <div class="hero-stat"><div class="hero-stat-value">10K+</div><div class="hero-stat-label">Products</div></div>
      <div class="hero-stat"><div class="hero-stat-value">50K+</div><div class="hero-stat-label">Happy Buyers</div></div>
      <div class="hero-stat"><div class="hero-stat-value">⭐ 4.8</div><div class="hero-stat-label">Average Rating</div></div>
    </div>
  </div>
  <div class="hero-emoji">🌍</div>
</div>

<div class="main-container">
  <!-- Sidebar Filters -->
  <aside class="sidebar-filters">
    <div class="filter-section">
      <div class="filter-title"><i class="fas fa-tags"></i> Categories</div>
      <div class="filter-list">
        <a href="index.php" class="filter-item <?= !$category_filter ? 'active' : '' ?>">
          <i class="fas fa-th-large"></i> All Categories
        </a>
        <?php mysqli_data_seek($categories, 0); while ($cat = mysqli_fetch_assoc($categories)): ?>
        <a href="index.php?category=<?= $cat['id'] ?>" class="filter-item <?= $category_filter == $cat['id'] ? 'active' : '' ?>">
          <span style="margin-right: 4px;"><?= htmlspecialchars($cat['icon'] ?? '📦') ?></span> <?= htmlspecialchars($cat['name']) ?>
        </a>
        <?php endwhile; ?>
      </div>
    </div>

    <div class="filter-section">
      <div class="filter-title"><i class="fas fa-dollar-sign"></i> Price Range</div>
      <form action="index.php" method="GET" class="price-range">
        <input type="hidden" name="category" value="<?= $category_filter ?>"/>
        <input type="number" name="price_min" placeholder="Min" value="<?= $price_min > 0 ? $price_min : '' ?>"/>
        <input type="number" name="price_max" placeholder="Max" value="<?= $price_max < 999999 ? $price_max : '' ?>"/>
        <button type="submit">Go</button>
      </form>
    </div>

    <div class="filter-section">
      <div class="filter-title"><i class="fas fa-box-open"></i> Condition</div>
      <div class="filter-list">
        <a href="<?= strtok($_SERVER['REQUEST_URI'], '?') ?>" class="filter-item <?= !$condition_filter ? 'active' : '' ?>">All Conditions</a>
        <a href="?<?= http_build_query(array_merge($_GET, ['condition' => 'new'])) ?>" class="filter-item <?= $condition_filter == 'new' ? 'active' : '' ?>"><span class="condition-tag condition-new">New</span> Brand New</a>
        <a href="?<?= http_build_query(array_merge($_GET, ['condition' => 'used'])) ?>" class="filter-item <?= $condition_filter == 'used' ? 'active' : '' ?>"><span class="condition-tag condition-used">Used</span> Pre-owned</a>
        <a href="?<?= http_build_query(array_merge($_GET, ['condition' => 'refurbished'])) ?>" class="filter-item <?= $condition_filter == 'refurbished' ? 'active' : '' ?>"><span class="condition-tag condition-refurbished">Refurb</span> Refurbished</a>
      </div>
    </div>

    <div class="filter-section manufacturer-sidebar">
      <div class="filter-title"><i class="fas fa-industry"></i> Manufacturers</div>
      <div class="filter-list">
        <?php mysqli_data_seek($manufacturers, 0); while ($m = mysqli_fetch_assoc($manufacturers)): ?>
        <a href="index.php?manufacturer=<?= $m['id'] ?>" class="filter-item <?= $manufacturer_filter == $m['id'] ? 'active' : '' ?>">
          <div class="manufacturer-item" style="padding: 0; width: 100%;">
            <img src="<?= !empty($m['logo']) ? 'uploads/products/' . htmlspecialchars($m['logo']) : '' ?>" alt="" onerror="this.style.display='none'"/>
            <div class="manufacturer-info">
              <div class="name"><?= htmlspecialchars($m['company_name']) ?></div>
              <div class="location">📍 <?= htmlspecialchars($m['country'] ?? 'Global') ?> · <?= number_format($m['total_sales']) ?> sales</div>
            </div>
          </div>
        </a>
        <?php endwhile; ?>
      </div>
    </div>
  </aside>

  <!-- Products Area -->
  <div class="products-area">
    <div class="results-header">
      <div class="results-count">Showing <strong><?= $total_products ?></strong> products from verified manufacturers</div>
      <div class="sort-bar">
        <label>Sort by:</label>
        <select onchange="window.location.href=this.value">
          <option value="?<?= http_build_query(array_merge($_GET, ['sort' => 'featured'])) ?>" <?= $sort == 'featured' ? 'selected' : '' ?>>Featured</option>
          <option value="?<?= http_build_query(array_merge($_GET, ['sort' => 'price_low'])) ?>" <?= $sort == 'price_low' ? 'selected' : '' ?>>Price: Low to High</option>
          <option value="?<?= http_build_query(array_merge($_GET, ['sort' => 'price_high'])) ?>" <?= $sort == 'price_high' ? 'selected' : '' ?>>Price: High to Low</option>
          <option value="?<?= http_build_query(array_merge($_GET, ['sort' => 'newest'])) ?>" <?= $sort == 'newest' ? 'selected' : '' ?>>Newest First</option>
          <option value="?<?= http_build_query(array_merge($_GET, ['sort' => 'popular'])) ?>" <?= $sort == 'popular' ? 'selected' : '' ?>>Most Popular</option>
          <option value="?<?= http_build_query(array_merge($_GET, ['sort' => 'rating'])) ?>" <?= $sort == 'rating' ? 'selected' : '' ?>>Top Rated</option>
        </select>
      </div>
    </div>

    <?php if ($total_products === 0): ?>
      <div class="no-products">
        <div class="no-products-icon">📦</div>
        <h3>No Products Found</h3>
        <p>Try adjusting your filters or search terms to find what you're looking for.</p>
        <a href="index.php" class="btn-register" style="display: inline-block; margin-top: 16px;">Clear All Filters</a>
      </div>
    <?php else: ?>
      <div class="products-grid">
        <?php mysqli_data_seek($products, 0); while ($p = mysqli_fetch_assoc($products)): 
          $img_path = !empty($p['image_url']) ? 'uploads/products/' . $p['image_url'] : '';
          $cart_img = !empty($img_path) && file_exists($img_path) ? $img_path : '🧸';
          $badge_class = strtolower($p['badge'] ?? '') == 'new' ? 'new' : (strtolower($p['badge'] ?? '') == 'sale' ? 'sale' : '');
        ?>
        <div class="product-card">
          <?php if (!empty($p['badge'])): ?>
          <div class="product-badge <?= $badge_class ?>"><?= htmlspecialchars($p['badge']) ?></div>
          <?php endif; ?>
          <div class="product-img">
            <?php if (!empty($p['image_url']) && file_exists('uploads/products/' . $p['image_url'])): ?>
              <img src="uploads/products/<?= htmlspecialchars($p['image_url']) ?>" alt="<?= htmlspecialchars($p['name']) ?>"/>
            <?php else: ?>🧸<?php endif; ?>
          </div>
          <div class="product-body">
            <div class="manufacturer-row">
              <?php if (!empty($p['manufacturer_logo']) && file_exists('uploads/products/' . $p['manufacturer_logo'])): ?>
                <img src="uploads/products/<?= htmlspecialchars($p['manufacturer_logo']) ?>" alt=""/>
              <?php else: ?><span style="font-size: 14px;">🏭</span><?php endif; ?>
              <span><?= htmlspecialchars($p['company_name'] ?? 'Unknown') ?></span>
              <span class="verified"><i class="fas fa-check-circle"></i> Verified</span>
            </div>
            <div class="product-name"><?= htmlspecialchars($p['name']) ?></div>
            <div class="product-rating">
              <span class="stars"><?= str_repeat('★', round($p['rating'] ?? 5)) . str_repeat('☆', 5 - round($p['rating'] ?? 5)) ?></span>
              <span class="review-count">(<?= $p['review_count'] ?? rand(10, 200) ?>)</span>
            </div>
            <div class="product-price">
              <span class="price-current">Tsh<?= number_format($p['price'], 0) ?></span>
              <?php if (!empty($p['old_price']) && $p['old_price'] > 0): ?>
                <span class="price-old">Tsh<?= number_format($p['old_price'], 0) ?></span>
              <?php endif; ?>
            </div>
            <div class="product-meta">
              <span><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($p['manufacturer_country'] ?? 'Global') ?></span>
              <span><i class="fas fa-truck"></i> <?= htmlspecialchars($p['estimated_delivery'] ?? '7-14 days') ?></span>
              <span class="condition-tag condition-<?= $p['condition_type'] ?? 'new' ?>"><?= ucfirst($p['condition_type'] ?? 'New') ?></span>
            </div>
            <a href="cart.php?add=<?= $p['id'] ?>&name=<?= urlencode($p['name']) ?>&price=<?= $p['price'] ?>&image=<?= urlencode($cart_img) ?>" class="btn-cart">
              <i class="fas fa-shopping-cart"></i> Add to Cart
            </a>
          </div>
        </div>
        <?php endwhile; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<footer>
  <div class="footer-main">
    <div>
      <div class="footer-logo">🍼 BabyBliss Marketplace</div>
      <p class="footer-about">The trusted marketplace for baby products. Connect directly with manufacturers worldwide. Every purchase is protected with our secure escrow system.</p>
    </div>
    <div class="footer-col">
      <h4>Buyers</h4>
      <ul>
        <li><a href="#">How to Buy</a></li>
        <li><a href="#">Buyer Protection</a></li>
        <li><a href="#">Shipping Guide</a></li>
        <li><a href="#">Returns & Refunds</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Sellers</h4>
      <ul>
        <li><a href="register.php?role=manufacturer">Become a Seller</a></li>
        <li><a href="#">Seller Center</a></li>
        <li><a href="#">Seller Protection</a></li>
        <li><a href="#">Commission Rates</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Support</h4>
      <ul>
        <li><a href="#">Help Center</a></li>
        <li><a href="#">Dispute Resolution</a></li>
        <li><a href="#">Contact Us</a></li>
        <li><a href="#">Report a Product</a></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <p>© 2026 BabyBliss Marketplace. All rights reserved. Secure escrow payments · Verified sellers · Buyer protection</p>
  </div>
</footer>


<script>
  let cur = 0; const total = 4;
  function moveSlide(dir) { cur = (cur + dir + total) % total; updateCarousel(); }
  function goSlide(i) { cur = i; updateCarousel(); }
  function updateCarousel() {
    document.getElementById('carousel').style.transform = `translateX(-${cur*100}%)`;
    document.querySelectorAll('.dot').forEach((d,i) => d.classList.toggle('active', i===cur));
  }
  setInterval(() => moveSlide(1), 5000);
</script>
</body>
</html>